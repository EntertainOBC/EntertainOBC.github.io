# This file is part of EntertainOBClub.

#     EntertainOBClub is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.

#     EntertainOBClub is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.

#     You should have received a copy of the GNU General Public License
#     along with EntertainOBClub.  If not, see <http://www.gnu.org/licenses/>.
   
 # Color template - [COLOR blue] [/COLOR]
import xbmcaddon,os,requests,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin

__addon__ = xbmcaddon.Addon()



User_Class_Username = xbmcaddon.Addon().getSetting("username")
User_Class_Password = xbmcaddon.Addon().getSetting("password")
TXT = '.txt'
Main_Directory = 'http://entertainobc.github.io/CHANNELS'
# Links
USA_TV = 'channel-type=USA_CHANNELS'
RADIO = 'channel-type=RADIO_CHANNELS'
TWENTYFOUR_SEVEN = 'channel-type=247_CHANNELS'
UK_TV_SPORTS_MOVIES = 'channel-type=UK_TV_SPORTS_AND_MOVIES'
TPK_MUSIC = 'channel-type=TPK_-_MUSIC'
LOCAL_SPANISH_CHANNELS = 'channel-type=LOCAL_SPANISH_CHANNELS'
LOCAL_NEWS_CHANNELS = 'channel-type=LOCAL_NEWS_CHANNELS'
CANADIAN_TV_CHANNELS = 'channel-type=CANADIAN_CHANNELS'
LATINO_SPANISH_TV = 'channel-type=LATINO_SPANISH_TV'
USERNAME_TAG = 'user='
PASSWORD_TAG = 'pass='
AND_TAG = '&'
SLASH = '/'
Auto_Login = False
Base56_url = "https://entertainobc.github.io/USERS/accesscode_name_dc1943&keyd34i93/Customers.txt"
# User Connector Modules 
USER_USA_TV_CONNECTOR = Main_Directory + SLASH + USA_TV + SLASH + USERNAME_TAG + User_Class_Username + AND_TAG + PASSWORD_TAG + User_Class_Password + TXT
USER_RADIO_CONNECTOR = Main_Directory + SLASH + RADIO + SLASH + USERNAME_TAG + User_Class_Username + AND_TAG + PASSWORD_TAG + User_Class_Password + TXT 
USER_TWENTYFOUR_SEVEN_CONNECTOR = Main_Directory + SLASH + TWENTYFOUR_SEVEN + SLASH + USERNAME_TAG + User_Class_Username + AND_TAG + PASSWORD_TAG + User_Class_Password + TXT
#USER_UK_TV_SPORTS_MOVIES_CONNTECTOR Main_Directory + SLASH + UK_TV_SPORTS_AND_MOVIES + SLASH + USERNAME_TAG + User_Class_Username + AND_TAG + PASSWORD_TAG + User_Class_Password + TXT
def LOGINFUNCTION():
	Base_Database = requests.get(Base56_url)
	Base_Finder = re.compile('user= "(.+?)" pass= "(.+?)" name= "(.+?)" exp= "(.+?)"').findall(Base_Database.content)
	for found_username,found_password,found_name, found_expdate in Base_Finder:
		global found_expdate1
		global found_name1
		found_expdate1 = found_expdate
		found_name1 = found_name
		if User_Class_Username == found_username and User_Class_Password == found_password:
			ACCOUNTCOMPLETED()
		if not User_Class_Username == found_username and not User_Class_Password == found_password:
			xbmcgui.Dialog().ok("USER DETAILS INCORRECT", "Incorrect USERNAME or PASSWORD", "If you believe this is a bug", "please report to a admin!")
			LOGIN()
	

	

def LOGIN():
	if Auto_Login == True:
		print ('1a')
	else:
		addDir('[COLOR gold]1. ENTER CREDENTIALS[/COLOR]',Main_Directory,7,'http://i.imgur.com/ZFTaQfL.png') 
		addDir('[COLOR red]2. LOGIN AND ENJOY[/COLOR]',Main_Directory,8,'http://i.imgur.com/ZFTaQfL.png') 
	
def LOGINS():
	xbmcaddon.Addon().openSettings()
	LOGIN()

def ACCOUNTCHECK():
	LOGINFUNCTION()

def ACCOUNTCOMPLETED():
	xbmcgui.Dialog().ok("WELCOME", found_name1, "Welcome to EntertainOBClub", "please enjoy our service!")
	CATEGORIES()
 









def CATEGORIES():
   addDir3('[COLOR gold]SUPPORT[/COLOR]',Main_Directory,10,'https://cdn2.iconfinder.com/data/icons/medicine-4-1/512/dispatcher-512.png','','') 
   addDir3('[COLOR gold]MY ACCOUNT[/COLOR]',Main_Directory,9,'https://cdn4.iconfinder.com/data/icons/minimal-user-interface-glyph-1/64/account_interface_ui_ux_software_app-512.png','','')
   addDir3('[COLOR blue]USA TV[/COLOR]',USER_USA_TV_CONNECTOR,4,'https://thumbs.dreamstime.com/b/usa-text-8310994.jpg','','')
   addDir3('[COLOR blue]RADIO[/COLOR]',USER_RADIO_CONNECTOR,5,'http://simpleicon.com/wp-content/uploads/antenna-2.svg','','') 
   addDir3('[COLOR blue]24/7 CHANNELS[/COLOR]',USER_TWENTYFOUR_SEVEN_CONNECTOR,6,'http://i.imgur.com/ZFTaQfL.png','','') 
   #addDir3('[COLOR blue]UK TV SPORTS AND MOVIES CHANNELS[/COLOR]',USER_UK_TV_SPORTS_MOVIES_CONNTECTOR,6,'https://previews.123rf.com/images/prawny/prawny1008/prawny100800019/7684222-graphic-illustration-of-the-word-uk-made-up-of-lots-of-little-union-jack-british-flags-isolated-on-w.jpg','','') 
   
def ACCOUNTINFO():
	addDir('[COLOR gray]Check Service Exp Date[/COLOR]',Main_Directory,11,'https://cdn3.iconfinder.com/data/icons/business-office-2/512/calendar_done-512.png') 

def CHECKDATES():
	Base_Database_Date = requests.get(Base56_url)
	Base_Finder_INFOS = re.compile('user= "(.+?)" pass= "(.+?)" name= "(.+?)" exp= "(.+?)"').findall(Base_Database_Date.content)
	for found_username,found_password,found_name, found_expdates in Base_Finder_INFOS:
		global found_expdates1
		found_expdates1 = found_expdates
		if User_Class_Username == found_username and User_Class_Password == found_password:
			xbmcgui.Dialog().ok("EXP DATE", found_expdates1, "is your expiration date", "please enjoy EntertainOBClub!")
			ACCOUNTINFO()
		if not User_Class_Username == found_username and User_Class_Password == found_password:
			xbmcgui.Dialog().ok("EXP DATE", "We couldn't get your expiration date", "please try again", "later, thank you.")
			LOGIN()


def SUPPORT():
	xbmcgui.Dialog().ok("SUPPORT", "Please Goto Our Discord", "If you need any support, Thank You", "And Enjoy EntertainOBClub!")
	CATEGORIES()
  
def UTV():
   r = requests.get(USER_USA_TV_CONNECTOR)
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
	 addLink(name,link,logo,'','')
def RD():
   r = requests.get(USER_RADIO_CONNECTOR)
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
	 addLink(name,link,logo,'','')
def TWENTYFOURS():
   r = requests.get(USER_TWENTYFOUR_SEVEN_CONNECTOR)
   match = re.compile('name= (.+?) url= "(.+?)" logo= "(.+?)"').findall(r.content)
   for name,link, logo in match:
	 addLink(name,link,logo,'','')


def addLink(name,url,image,urlType,fanart):
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		liz.setProperty('IsPlayable','true')
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)


def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param       
#################################################################################################################

#                               NEED BELOW CHANGED

  
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
	 
def addDir2(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
		liz.setProperty( "Fanart_Image", fanart )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view')=='true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % viewType )
 


			  
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:        
		mode=int(params["mode"])
except:
		pass
try:        
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:        
		description=urllib.unquote_plus(params["description"])
except:
		pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
		print ""
		LOGIN()
	   
elif mode==1:
		OPEN_URL(url)
elif mode==3:
		sidemessage()
elif mode==4:
		UTV()
elif mode==5:
		RD()
elif mode==6:
		TWENTYFOURS()
elif mode==7:
		LOGINS()
elif mode==8:
		ACCOUNTCHECK()
elif mode==9:
	    ACCOUNTINFO()    
elif mode==10:
	    SUPPORT()	    
elif mode==11:
	    CHECKDATES()


		


xbmcplugin.endOfDirectory(int(sys.argv[1]))
